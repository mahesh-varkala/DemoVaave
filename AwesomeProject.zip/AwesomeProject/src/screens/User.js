import React, { Component } from 'react';

import {
  Text,
  StyleSheet,
  View,
  Image,
} from 'react-native';
import { Icon } from 'native-base';

export default class User extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { name, company, website, address } = this.props.navigation.getParam('data')
    return (
      <View style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
        </View>
        <View style={{ flex: 3, justifyContent: 'center', alignItems: 'center' }}>
          <Image source={require('../assets/avatar.jpg')} style={{ height: 100, width: 100 }} />
          <Text style={{ paddingTop: 10, paddingBottom: 20, color: 'black', fontWeight: 'bold' }}>{name}</Text>

          <View style={styles.listView}>
            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
              <Text style={styles.leftText}>Lives in</Text>
              <Icon name="location" style={{ fontSize: 16 }} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rightText}>{address.city}</Text>
            </View>
          </View>
          <View style={styles.listView}>
            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
              <Text style={styles.leftText}>Website</Text>
              <Icon name="contacts" type="MaterialIcons" style={{ fontSize: 16 }} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rightText}>{website}</Text>
            </View>
          </View>
          <View style={styles.listView}>
            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
              <Text style={styles.leftText}>Works at</Text>
              <Icon name="office-building" type="MaterialCommunityIcons" style={{ fontSize: 16 }} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rightText}>{company.name}</Text>
            </View>
          </View>
        </View>
        <View style={{ flex: 1 }}>
        </View>
      </View >
    );
  }
}
const styles = StyleSheet.create({
  textStyle: {
    padding: 20,
  },
  leftText: {
    padding: 5, color: 'black', fontWeight: '500'
  },
  rightText: {
    padding: 5, color: 'black', fontWeight: 'bold'
  },
  listView: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start', width: '80%',
  }
});
