import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  FlatList,
  ActivityIndicator,
  ScrollView,
  SafeAreaView,
} from "react-native";
import { Container, Icon, Card, Body, CardItem, Left, Right, Content, Footer, Header, Item, Input } from "native-base";
import CustomHeader from "../components/CustomHeader";
import SearchComponent from "../components/SearchComponent";
import { colors } from "../util/appStyles";
import PostsComponent from "../components/PostsComponent";
import StoriesComponent from "../components/StoriesComponent";
import SearchResult from "../components/SearchResult";

const data = [
  { name: 'First' },
  { name: 'Second' },
  { name: 'Third' },
  { name: 'Fourth' },
  { name: 'Fifth' },
  { name: 'Sixth' },
  { name: 'Seventh' },
  { name: 'Eighth' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
]

class Home extends Component {

  constructor() {
    super()
    this.state = {
      text: '',
      dataSource: [],
    }
  }

  componentDidMount() {
    this.getPosts();
  }

  getPosts() {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(posts => {
        // console.log(posts)
        this.setState({ posts })
      })
  }

  onChangeText = (text, dataSource) => {
    this.setState({ text, dataSource })
  }

  render() {
    const { text, dataSource } = this.state;
    return (
      <Container>
        <Header style={{ backgroundColor: 'white', height: 80 }} androidStatusBarColor='white'>
          <Body style={{ justifyContent: 'center', alignItems: 'center' }}>
            <SearchComponent onChangeText={this.onChangeText} />
          </Body>
        </Header>

        {/* <View style={{ backgroundColor: 'white', height: 80 }} androidStatusBarColor='white'>
          <View style={{ justifyContent: 'center', alignItems: 'center' }}>
            <SearchComponent onChangeText={this.onChangeText} />
          </View>
        </View> */}

        {/* {
            text ?
              null :
              <View style={{ height: 100 }}>
                <StoriesComponent />
              </View>
          } */}

        {
          text ?
            <SearchResult dataSource={dataSource} navProps={this.props.navigation} /> :
            <View>
              <View style={{
                marginHorizontal: 20, height: 40,
                flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <Text style={{ fontSize: 14, fontWeight: '500', }}>POSTS</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Text style={{ color: 'grey', fontSize: 12, marginRight: 4, }}>Filter by</Text>
                  <Icon name="sort" type="MaterialIcons" style={{ color: 'black', fontSize: 12 }} />
                </View>
              </View>
              <PostsComponent navProps={this.props.navigation} />
            </View>
        }

      </Container>
    );
  }
}
export default Home;