import React, { Component } from "react";
import { withNavigation } from 'react-navigation';
import { createAppContainer } from "react-navigation";

import { HomeStackNavigator } from './navs';

const AppHome = createAppContainer(HomeStackNavigator)

export default withNavigation(AppHome)