import { createSwitchNavigator, createAppContainer } from 'react-navigation';

import AppHome from './AppHome'

const AppNavigator = createSwitchNavigator({
  AppHome: {
    screen: AppHome
  }
});

export default createAppContainer(AppNavigator);
