import { createStackNavigator } from 'react-navigation-stack';

import Home from '../screens/Home';
import User from '../screens/User';
import Post from '../screens/Post';

exports.HomeStackNavigator = createStackNavigator(
  {
    Home: {
      screen: Home
    },
    User: {
      screen: User
    },
    Post: {
      screen: Post
    }
  },
  {
    headerMode: 'none',
    navigationOptions: {
      headerVisible: false
    }
  }
)