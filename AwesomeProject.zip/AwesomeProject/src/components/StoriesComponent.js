import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  FlatList,
  ActivityIndicator,
  SafeAreaView,
} from "react-native";

const data = [
  { name: 'First' },
  { name: 'Second' },
  { name: 'Third' },
  { name: 'Fourth' },
  { name: 'Fifth' },
  { name: 'Sixth' },
  { name: 'Seventh' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
  { name: 'First' },
]

function StoriesComponent() {


  return (
    data ?
      <SafeAreaView style={{ flex: 1 }}>
        <FlatList
          style={{ marginHorizontal: 10, marginTop: 10, }}
          data={data}
          renderItem={({ item }) =>
            <View style={{ height: 60, width: 80, alignItems: 'center' }}>
              <TouchableOpacity
                activeOpacity={0.8}
                style={{ height: 60, width: 60, borderRadius: 50, backgroundColor: 'lightgrey', }}
              >
                <Image source={require('../assets/avatar.jpg')} resizeMethod="resize" style={{ height: 60, width: 60, borderRadius: 50, borderColor: 'grey', borderWidth: 0.5 }} />
              </TouchableOpacity>
              <View style={{ alignItems: 'center' }}>
                <Text style={{ fontSize: 12, }}>{item.name}</Text>
              </View>
            </View>
          }
          keyExtractor={(item, index) => item.name + index}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
        />
      </SafeAreaView >
      :
      <ActivityIndicator />

  );

}
export default StoriesComponent;

