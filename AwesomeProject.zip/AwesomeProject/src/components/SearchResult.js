import React, { Component } from 'react';

import {
  Text,
  StyleSheet,
  View,
  FlatList,
  Image,
  TouchableOpacity
} from 'react-native';
import { Icon } from 'native-base';

export default class SearchResult extends Component {
  constructor(props) {
    super(props);
    console.log(props)
  }

  render() {
    const { dataSource } = this.props;
    return (
      // <FlatList
      //   data={dataSource}
      //   // ItemSeparatorComponent={this.ListViewItemSeparator}
      //   renderItem={({ item }) => (
      //     <TouchableOpacity onPress={() => alert(item.email)}
      //       style={{ flexDirection: 'row', alignItems: 'center', paddingLeft: 30, height: 60, borderBottomWidth: 0.2 }}
      //     >
      //       <Image source={require('../assets/avatar.jpg')} resizeMethod="resize" style={{ height: 30, width: 30, borderRadius: 50, borderColor: 'grey', borderWidth: 0.5 }} />
      //       <Text style={styles.textStyle}>{item.username}</Text>
      //     </TouchableOpacity>
      //   )}
      //   // enableEmptySections={true}
      //   style={{ marginTop: 10, width: '100%', }}
      //   keyExtractor={(item, index) => index.toString()}
      // />
      dataSource.length > 0 ?
        dataSource.map((item, index) => {
          return (
            <TouchableOpacity
              key={index}
              onPress={() => this.props.navProps.navigate('User', { 'data': item })}
              style={{ flexDirection: 'row', alignItems: 'center', paddingLeft: 30, height: 60, borderBottomWidth: 0.2 }}
            >
              <Image source={require('../assets/avatar.jpg')} resizeMethod="resize" style={{ height: 30, width: 30, borderRadius: 50, borderColor: 'grey', borderWidth: 0.5 }} />
              <Text style={styles.textStyle}>{item.username}</Text>
            </TouchableOpacity>
          );
        }) :
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text>No Data Found</Text>
        </View>
    );
  }
}
const styles = StyleSheet.create({
  textStyle: {
    padding: 20,
  },
});
