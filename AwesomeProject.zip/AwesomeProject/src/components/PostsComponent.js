import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
} from "react-native";

class PostsComponent extends Component {

  constructor() {
    super()
    this.state = {
      posts: null,
    }
  }

  componentDidMount() {
    this.getPosts();
  }

  getPosts() {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(posts => {
        // console.log(posts)
        this.setState({ posts })
      })
  }

  render() {
    const { posts } = this.state;

    return (
      posts ?
        <FlatList
          style={{ marginHorizontal: 10, }}
          data={posts}
          renderItem={({ item }) =>
            <TouchableOpacity
              onPress={() => this.props.navProps.navigate('Post', { 'data': item })}
            >
              <View
                style={{
                  flexDirection: 'row',
                  height: 120,
                  borderRadius: 5,
                  borderWidth: 0.2,
                  marginVertical: 5,
                  borderColor: 'grey',
                }}>
                <View style={{ flex: 1, backgroundColor: 'lightgrey', justifyContent: 'center', alignItems: 'center', borderRightWidth: 0.2, borderColor: 'grey', borderRadius: 5 }}>
                  <Image source={require('../assets/avatar.jpg')} style={{ height: 60, width: 60 }} />
                  <Text style={{ fontWeight: '500', fontSize: 12, marginTop: 5 }}>{item.userId}</Text>
                </View>
                <View style={{ flex: 2, justifyContent: 'center', padding: 10 }}>
                  <View style={{ flex: 1, justifyContent: 'center' }}>
                    <Text numberOfLines={1} style={{ fontWeight: 'bold', fontSize: 14, }}>{item.title.toUpperCase()}</Text>
                  </View>
                  <View style={{ flex: 4, justifyContent: 'center' }}>
                    <Text numberOfLines={4} style={{ fontWeight: '500', fontSize: 14, color: 'grey', flexShrink: 1 }} >{item.body}</Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          }
          keyExtractor={(item, index) => item.id.toString() + index}
          showsVerticalScrollIndicator={false}
        /> :
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator style={{}} size="large" color="blue" />
        </View>
    );
  }
}
export default PostsComponent;