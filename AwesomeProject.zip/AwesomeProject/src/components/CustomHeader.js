import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity
} from "react-native";
import { Container, Header, Left, Body, Right, Button, Icon, Title, } from 'native-base';
// import { Ionicons, AntDesign, Entypo, FontAwesome, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';

import { colors, alignCenter } from '../util/appStyles'

const TEXT_COLOR_1 = colors.TEXT_COLOR_1;
const MSG = 'MESSAGE'
const URL = 'http://moduluspi.com/'
class CustomHeader extends Component {

  constructor(props) {
    super(props)
    console.log(props)
    this.state = {
    }
  }

  render() {

    const { showMenu, shareOption, showBack } = this.props
    const shareOptions = {
      title: 'Share via',
      message: MSG,
      url: URL,
      // social: Share.Social.WHATSAPP,
      // whatsAppNumber: "9199999999",  // country code + phone number
      // filename: 'test', // only for base64 file in Android 
    };

    return (
      <Header style={{ backgroundColor: 'white' }} iosBarStyle='light-content' androidStatusBarColor='white'>
        <Left style={{ flex: 1 }}>
          {
            showMenu ?
              <TouchableOpacity onPress={() => { this.props.navprops.openDrawer() }} >
                {/* <AntDesign name="left" style={{ fontSize: 28, color: 'black' }} /> */}
              </TouchableOpacity> :
              (
                showBack ?
                  <TouchableOpacity onPress={() => { this.props.navprops.goBack() }} >
                  </TouchableOpacity> :
                  null
              )
          }
        </Left>
        <Body style={[{ flex: 3 }, alignCenter]}>
          <Title style={{ color: 'black' }}>{this.props.title}</Title>
        </Body>
        <Right style={{ flex: 1 }}>
          {
            shareOption ?
              <TouchableOpacity
                style={{ flexDirection: 'row' }}
                onPress={this.props.onClickSearch(true)}
              >
                <Icon name="search" style={{ color: 'grey' }} />
              </TouchableOpacity> :
              null
          }
        </Right>
      </Header>
    );
  }
}
export default CustomHeader;

const styles = StyleSheet.create({
  linearGradient: {
    // height: Header.height
  },
});