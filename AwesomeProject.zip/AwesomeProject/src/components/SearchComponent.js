import React, { Component } from 'react';
import {
  Text,
  StyleSheet,
  View,
  FlatList,
  TextInput,
} from 'react-native';
import { Icon } from 'native-base';
import AsyncStorage from '@react-native-community/async-storage';

export default class SearchComponent extends Component {
  constructor(props) {
    super(props);
    //setting default state
    this.state = { isLoading: true, text: '' };
    this.arrayholder = [];
  }

  componentDidMount() {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(async (responseJson) => {
        await AsyncStorage.setItem('users', JSON.stringify(responseJson))
        console.log(responseJson)
        this.setState(
          {
            isLoading: false,
            dataSource: responseJson
          },
          function () {
            this.arrayholder = responseJson;
          }
        );
      })
      .catch(error => {
        console.error(error);
      });
  }
  SearchFilterFunction(text) {
    //passing the inserted text in textinput
    const newData = this.arrayholder.filter(function (item) {
      //applying filter for the inserted text in search bar
      const itemData = item.username ? item.username.toUpperCase() : ''.toUpperCase();
      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    this.props.onChangeText(text, newData)
    this.setState({
      //setting the filtered newData on datasource
      //After setting the data it will automatically re-render the view
      dataSource: newData,
      text: text,
    });
  }
  ListViewItemSeparator = () => {
    //Item sparator view
    return (
      <View
        style={{
          height: 0.3,
          width: '90%',
          backgroundColor: '#080808',
        }}
      />
    );
  };
  render() {
    return (
      <View style={{ flex: 1, width: '100%' }}>
        <View style={styles.textInput}>
          <Icon name="search" type="FontAwesome" style={{ marginLeft: 10, flex: 1, color: 'grey', fontSize: 16 }} />
          <TextInput
            placeholder="Search user"
            onChangeText={text => this.SearchFilterFunction(text)}
            value={this.state.text}
            underlineColorAndroid="transparent"
            style={{ flex: 9, fontSize: 16, marginLeft: 5, fontSize: 16 }}
          />
          <Icon name="sort" type="MaterialIcons" style={{ marginLeft: 10, flex: 1, color: 'grey', fontSize: 16 }} />
        </View>
      </View >
    );
  }
}
const styles = StyleSheet.create({
  textInput: {
    flexDirection: 'row',
    borderColor: 'rgba(220, 224, 232, 0.8)',
    backgroundColor: 'rgba(220, 224, 232, 0.8)',
    borderRadius: 25,
    borderWidth: 1,
    height: 50,
    // width: '100%',
    marginVertical: 10,
    marginHorizontal: 20,
    justifyContent: 'flex-start',
    alignItems: 'center',
    fontSize: 18,
  },

});
