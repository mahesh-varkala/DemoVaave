exports.colors = {
  BASE_COLOR: 'orange',
  BASE_COLOR_2: '#009F20',
  TEXT_COLOR_1: 'white',
  TEXT_COLOR_2: 'black',
  TEXT_COLOR_3: 'grey',
  ERROR_COLOR: 'red',
  ORANGE: 'orange',
  RED: 'red',
  GREEN: '#25FD03',
}

exports.alignCenter = {
  justifyContent: 'center',
  alignItems: 'center'
}

exports.appButton = {
  backgroundColor: 'green', height: 40, justifyContent: 'center', alignItems: 'center'
}

exports.appButtonTextBold = {
  color: 'white', fontWeight: 'bold', fontSize: 18
}

exports.appButtonTextNormal = {
  color: 'white', fontWeight: '400', fontSize: 18
}
