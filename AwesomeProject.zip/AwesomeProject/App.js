
import React from 'react';
import AppContainer from './src/navigators/AppNavigator';

class App extends React.Component {
  render() {
    return (
      <AppContainer />
    );
  }
}
export default App;